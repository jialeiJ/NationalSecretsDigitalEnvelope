<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <h1>加密前的请求数据：  {{ reqData }}</h1>
    <h1>解密后的响应数据：  {{ resData }}</h1>
    <button @click="test">数字信封发送请求</button>
    <!-- <h2>Essential Links</h2>
    <ul>
      <li>
        <a
          href="https://vuejs.org"
          target="_blank"
        >
          Core Docs
        </a>
      </li>
      <li>
        <a
          href="https://forum.vuejs.org"
          target="_blank"
        >
          Forum
        </a>
      </li>
      <li>
        <a
          href="https://chat.vuejs.org"
          target="_blank"
        >
          Community Chat
        </a>
      </li>
      <li>
        <a
          href="https://twitter.com/vuejs"
          target="_blank"
        >
          Twitter
        </a>
      </li>
      <br>
      <li>
        <a
          href="http://vuejs-templates.github.io/webpack/"
          target="_blank"
        >
          Docs for This Template
        </a>
      </li>
    </ul>
    <h2>Ecosystem</h2>
    <ul>
      <li>
        <a
          href="http://router.vuejs.org/"
          target="_blank"
        >
          vue-router
        </a>
      </li>
      <li>
        <a
          href="http://vuex.vuejs.org/"
          target="_blank"
        >
          vuex
        </a>
      </li>
      <li>
        <a
          href="http://vue-loader.vuejs.org/"
          target="_blank"
        >
          vue-loader
        </a>
      </li>
      <li>
        <a
          href="https://github.com/vuejs/awesome-vue"
          target="_blank"
        >
          awesome-vue
        </a>
      </li>
    </ul> -->
  </div>
</template>

<script>
import CryptoJS from "crypto-js";
import smCrypto from "sm-crypto";
import axios from 'axios'
import qs from 'qs'


const cipherMode = 0 // 选择加密策略，1 - C1C3C2，0 - C1C2C3，默认为1
const sysPrivateKey = "559f2f680d350c9732dc196a92fb009d5ce013dca3b431dff42ffc5c0d50e179";
const sysPublicKey = '04b8ad10bb99367037dde9e836eb82655460e51761748cb2e525dea1bc09bfd7011c86c60a200cae237ff95c98e996094563e1bcaa7b54263c70ef48d48a5b3ed3' // 系统后台公钥
const uiPrivateKey = 'ee2093b01888f1a65fef233404981f62087933eb9be969e3c64b442a7304127a' // 前端UI私钥
const uiPublicKey = "04cef5a9860af217790cecdbb2b5af5aaa1d472bf9cd69bed2d0fd562c2d93a0db151f289a920314755d0fe27b17a55a8a4a55e3d093b465e2a631540d4bbf2033";

// 后端进行加密解密时，keyStr与IvStr需要和后端保持一致
const defaultKeyStr = "smLeGV63judEcxKU";
const defaultIvStr = "lFbGSVuAmZqtPCLa";
const defaultKey = CryptoJS.enc.Utf8.parse(defaultKeyStr);
const defaultIv = CryptoJS.enc.Utf8.parse(defaultIvStr);
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: '数字信封(SM2、SHA256、AES)',
      reqData: null,
      resData: null
    }
  },
  mounted() {
    let that = this
  },
  methods: {
    test() {
      let that = this;

      let keypair = smCrypto.sm2.generateKeyPairHex()
      let publicKey = keypair.publicKey // 公钥
      let privateKey = keypair.privateKey // 私钥
      console.log("sm2公钥：", publicKey)
      console.log("sm2私钥：", privateKey)

      // 生成随机对称秘钥key、iv
      let keyStr = that.generateKeyOrIv(16)
      let ivStr = that.generateKeyOrIv(16)

      // 使用sm2(非对称密钥)加密key、iv
      let key = that.getSm2DataHexByString(keyStr)
      let iv = that.getSm2DataHexByString(ivStr)
      console.log('sm2加密后的key：', key)
      console.log('sm2加密后的iv：', iv)

      // 要加密的明文数据
      let param = {
        userName: "张三",
        age: 30,
        gender: 'M'
      }
      that.reqData = JSON.stringify(param)

      // 生成明文的信息摘要
      let sha256HexHash = CryptoJS.SHA256(that.reqData).toString(CryptoJS.enc.Hex).toUpperCase()
      console.log("明文数据的信息摘要：", sha256HexHash)
      let hash = that.encrypt(sha256HexHash, keyStr, ivStr)
      console.log("加密的信息摘要：", hash)


      let sign = smCrypto.sm2.doSignature(hash, uiPrivateKey, {der: true, hash: true})
      console.log("私钥对信息摘要的签名：", sign)

      const verifySign = smCrypto.sm2.doVerifySignature(hash, sign, '04cef5a9860af217790cecdbb2b5af5aaa1d472bf9cd69bed2d0fd562c2d93a0db151f289a920314755d0fe27b17a55a8a4a55e3d093b465e2a631540d4bbf2033', {der: true, hash: true} )
      console.log('测试校验签名验签结果：', verifySign)
      
      let params = {
        key: key,
        iv: iv,
        hash: hash,
        sign: sign,
        ciphertext: that.encrypt(that.reqData, keyStr, ivStr)
      }
    

      //'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'
      axios.post('http://localhost:8081/test',params,{
        headers: {
            'Content-Type':'application/json'
          }
      }).then(res=>{
        console.log("校验响应数据合法性：", that.VerifyDataLegality(res.data))
        that.parseEndData(res.data, keyStr, ivStr)
      },err =>{
        console.log(err)
      })


      //'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'
      axios.get('http://localhost:8081/test1', {params},{
        headers: {
            'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'
          }
      }).then(res=>{
        console.log("校验响应数据合法性：", that.VerifyDataLegality(res.data))
        that.parseEndData(res.data, keyStr, ivStr)
      },err =>{
        console.log(err)
      })
    },

    //随机生成指定位数的key或iv
    generateKeyOrIv(num) {
      let library = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
      let key = "";
      for (var i = 0; i < num; i++) {
        let randomPoz = Math.floor(Math.random() * library.length);
        key += library.substring(randomPoz, randomPoz + 1);
      }
      return key;
    },

    /**
     * 获取key
     * @param keyStr key字符串
     */
    getKey(keyStr) {
      if (keyStr) {
          return CryptoJS.enc.Utf8.parse(keyStr);
      }
      return defaultKey;
    },

    /**
     * 获取iv
     * @param ivStr iv字符串
     * @returns {*}
     */
    getIv(ivStr) {
      if (ivStr) {
          return CryptoJS.enc.Utf8.parse(ivStr);
      }
      return defaultIv;
    },

    /**
     * 对称加密
     * @param {*} word   明文字符串
     * @param {*} keyStr key
     * @param {*} ivStr  iv
     * @return 加密后内容
     */
    encrypt(word, keyStr, ivStr) {
      let that = this
      let key = that.getKey(keyStr);
      let iv = that.getIv(ivStr);

      let srcs = CryptoJS.enc.Utf8.parse(word);
      let encrypted = CryptoJS.AES.encrypt(srcs, key, {
          iv: iv,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.ZeroPadding
      });
      return CryptoJS.enc.Base64.stringify(encrypted.ciphertext);
    },

    /**
     * 对称解密
     * @param {*} word    已加密字符串
     * @param {*} keyStr  key
     * @param {*} ivStr   iv
     * @return 解密结果
     */
    decrypt(word, keyStr, ivStr) {
      let key = this.getKey(keyStr);
      let iv = this.getIv(ivStr);

      let base64 = CryptoJS.enc.Base64.parse(word);
      let src = CryptoJS.enc.Base64.stringify(base64);

      let decrypt = CryptoJS.AES.decrypt(src, key, {
          iv: iv,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.ZeroPadding
      });

      let decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
      return decryptedStr.toString();
    },

    /**
     * SM2加密string数据
     * @param {string} data 原始数据
     * @returns {string} 加密后数据
     */
    getSm2DataHexByString(data) {
      if (data && (typeof data === 'string') && data.constructor === String) {
        return '04' + smCrypto.sm2.doEncrypt(data, sysPublicKey, cipherMode)
      }
      return null
    },

    /**
     * SM2加密object数据
     * @param {Object} data 原始数据
     * @returns {string} 加密后数据
     */
    getSm2DataHexByObject(data) {
      if (data) {
        return '04' + smCrypto.sm2.doEncrypt(JSON.stringify(data), sysPublicKey, cipherMode)
      }
      return null
    },

    /**
     * SM2解密数据
     * @param {string} dataHex 原始加密数据
     * @returns {string} 解密后数据
     */
    getSm2DataByString(dataHex) {
      if (dataHex && (typeof dataHex === 'string') && dataHex.constructor === String) {
        dataHex = dataHex.substring(2).toLocaleLowerCase()
        return smCrypto.sm2.doDecrypt(dataHex, uiPrivateKey, cipherMode)
      }
    },

    /**
     * 校验响应数据合法性
     * @param {string} res 后端响应数据
     */
    VerifyDataLegality(res) {
      let that = this
      
      let realKey = that.getSm2DataByString(res.key)
      let realIv = that.getSm2DataByString(res.iv)
      console.log(realKey)
      console.log(realIv)

      // 验签
      console.log(res.hash)
      console.log(res.sign)
      const verifySign = smCrypto.sm2.doVerifySignature(res.hash, res.sign, sysPublicKey, {der: true, hash: true} )
      if (!verifySign) {
        return verifySign
      }
      console.log('签名验签结果：', verifySign)

      // 解密hash值
      let reqHashvalue = that.decrypt(res.hash, realKey, realIv)
      // 计算hash值
      let plaintext = that.decrypt(res.ciphertext, realKey, realIv)
      let calHashValue = CryptoJS.SHA256(plaintext).toString(CryptoJS.enc.Hex).toUpperCase()
      
      console.log(reqHashvalue)
      console.log(calHashValue)

      if (reqHashvalue != calHashValue) {
        return false
      }
      return true
    },

    /**
     * 解析后端数据
     */
    parseEndData(res) {
      let that = this
      
      let realKey = that.getSm2DataByString(res.key)
      let realIv = that.getSm2DataByString(res.iv)

      // 解密密文，得到明文
      let plaintext = that.decrypt(res.ciphertext, realKey, realIv)
      that.resData = JSON.parse(plaintext)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
