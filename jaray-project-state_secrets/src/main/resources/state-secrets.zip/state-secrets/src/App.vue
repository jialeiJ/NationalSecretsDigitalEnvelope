<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <HelloWorld/>
    <National_Secrets_HelloWorld/>
  </div>
</template>

<script>
import HelloWorld from './components/Digital_Envelope_HelloWorld'
import National_Secrets_HelloWorld from './components/National_Secrets_Digital_Envelope_HelloWorld'

export default {
  name: 'App',
  components: {
    HelloWorld,
    National_Secrets_HelloWorld
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
